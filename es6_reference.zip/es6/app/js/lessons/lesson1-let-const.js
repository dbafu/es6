function test() {
    const a= "1";
    console.log(a);
}

test();