// 项目入口文件

// ES6兼容处理
import 'babel-polyfill';
import Lottery from './lottery';

const syy = new Lottery();